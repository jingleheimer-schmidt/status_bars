## Status Bars
a mod for factorio
https://mods.factorio.com/mod/status_bars

---------------------
# Overview
This mod adds new status bars for armor durability and player/vehicle battery charge. It also adds per-player mod settings to individually show/hide the status bars and change their color.
<!-- 
---------------------
# Features

---------------------
# Gallery

---------------------
## Companion Mods -->

---------------------
# Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page.

---------------------
# License
Status Bars © 2023 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
